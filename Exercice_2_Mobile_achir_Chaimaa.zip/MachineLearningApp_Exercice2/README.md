# Machine Learning App

Cette application Android présente une interface utilisateur sur le Machine Learning en utilisant Jetpack Compose.

## Fonctionnalités

- Image en en-tête qui remplit toute la largeur de l'écran
- Titre "Machine Learning" avec une police de 24sp
- Deux paragraphes de texte justifié expliquant le Machine Learning
- Interface moderne avec Jetpack Compose
- Support du défilement vertical

## Technologies utilisées

- Kotlin
- Jetpack Compose
- Material Design 3
- Android SDK 24+

## Structure du projet

```
MachineLearningApp/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/example/machinelearning/
│   │       │   └── MainActivity.kt
│   │       ├── res/
│   │       │   ├── drawable/
│   │       │   │   └── ml_header.png
│   │       │   ├── values/
│   │       │   │   ├── strings.xml
│   │       │   │   └── themes.xml
│   │       │   └── xml/
│   │       │       ├── backup_rules.xml
│   │       │       └── data_extraction_rules.xml
│   │       └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## Installation

1. Ouvrir le projet dans Android Studio
2. Synchroniser le projet avec Gradle
3. Exécuter l'application sur un émulateur ou un appareil physique

## Configuration requise

- Android Studio Arctic Fox ou supérieur
- Android SDK 24 (Android 7.0) ou supérieur
- Kotlin 1.9.0

## Auteur

Développé dans le cadre d'un exercice académique
